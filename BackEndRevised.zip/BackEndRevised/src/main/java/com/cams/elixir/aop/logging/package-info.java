/**
 * Logging aspect.
 */
package com.cams.elixir.aop.logging;
