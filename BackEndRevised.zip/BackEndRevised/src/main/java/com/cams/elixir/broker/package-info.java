/**
 * Spring cloud consumers and providers
 */
package com.cams.elixir.broker;
