/**
 * Application configuration.
 */
package com.cams.elixir.config;
