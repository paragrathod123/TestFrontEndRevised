/**
 * Domain objects.
 */
package com.cams.elixir.domain;
