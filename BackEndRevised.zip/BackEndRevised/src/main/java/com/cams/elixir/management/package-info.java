/**
 * Application management.
 */
package com.cams.elixir.management;
