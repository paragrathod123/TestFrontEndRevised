/**
 * Application root.
 */
package com.cams.elixir;
