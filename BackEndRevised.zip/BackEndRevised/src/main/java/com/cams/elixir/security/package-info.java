/**
 * Application security utilities.
 */
package com.cams.elixir.security;
