/**
 * Data transfer objects for rest mapping.
 */
package com.cams.elixir.service.dto;
