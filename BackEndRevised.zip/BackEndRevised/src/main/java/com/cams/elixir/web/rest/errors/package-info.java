/**
 * Rest layer error handling.
 */
package com.cams.elixir.web.rest.errors;
