/**
 * Rest layer.
 */
package com.cams.elixir.web.rest;
