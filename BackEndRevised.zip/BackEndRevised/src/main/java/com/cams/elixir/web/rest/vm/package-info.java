/**
 * Rest layer visual models.
 */
package com.cams.elixir.web.rest.vm;
