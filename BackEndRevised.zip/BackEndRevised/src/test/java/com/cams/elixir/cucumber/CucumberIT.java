package com.cams.elixir.cucumber;

import com.cams.elixir.IntegrationTest;
import io.cucumber.junit.platform.engine.Cucumber;

@Cucumber
@IntegrationTest
class CucumberIT {}
